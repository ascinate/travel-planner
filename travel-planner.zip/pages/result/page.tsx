"use client";

import { useEffect, useState } from "react";
import ReactMarkdown from "react-markdown";
import rehypeRaw from "rehype-raw";

export default function ResultPage() {
  return (
    <div>
      <h1>Result Page</h1>
    </div>
  );
}
